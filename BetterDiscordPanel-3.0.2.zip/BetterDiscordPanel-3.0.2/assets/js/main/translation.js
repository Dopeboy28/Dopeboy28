/**
 * @file translation.js
 * @author Sanjay Sunil
 * @license GPL-3.0
 */

// BetterDiscordPanel

